//
//  Error_NilApp.swift
//  Error Nil
//
//  Created by Jin O on 2023/06/07.
//

import SwiftUI

@main
struct Error_NilApp: App {
    @StateObject private var viewModel = ViewModel()
    var body: some Scene {
        WindowGroup {
            ContentView()
                
                }
        }
    }
