//
//  ContentView.swift
//  Error Nil
//
//  Created by Jin O on 2023/06/07.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView {
            Welcome()
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
